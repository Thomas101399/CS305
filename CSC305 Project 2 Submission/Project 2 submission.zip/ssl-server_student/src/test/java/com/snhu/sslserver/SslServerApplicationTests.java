/******************************************************************
** 
** CS-305 Project 2
** SslServerApplication.java
** 
** Thomas Conahan
** Southern New Hampshire University
** CS-305-T3312 Software Security
** Dr. Vivian Lyon
** February 14, 2023
**
******************************************************************/


package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SslServerApplicationTests {

	@Test
	void contextLoads() 
	{
	}

}
